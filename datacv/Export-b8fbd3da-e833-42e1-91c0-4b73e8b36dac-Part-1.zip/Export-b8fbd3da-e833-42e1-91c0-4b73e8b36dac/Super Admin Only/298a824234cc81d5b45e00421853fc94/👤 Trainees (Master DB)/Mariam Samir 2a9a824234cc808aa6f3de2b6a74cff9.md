# Mariam Samir

Assessment: Final Batch 13 (../%F0%9F%93%88%20Assessments%20(Master%20DB)/Final%20Batch%2013%202aea824234cc80c0b0fcef13bf52c667.md)
Batch: Batch 13 (../%F0%9F%8E%93%20Batches%20(Master%20DB)/Batch%2013%202a9a824234cc80a7b9fae7ddae75b810.md)
Company: Projex