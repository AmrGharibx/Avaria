# Abdelrahman Tarek

Assessment: Final Batch 6 (../%F0%9F%93%88%20Assessments%20(Master%20DB)/Final%20Batch%206%202aaa824234cc80309cf9efa768c39cfc.md)
Batch: Batch 6 (../%F0%9F%8E%93%20Batches%20(Master%20DB)/Batch%206%202a9a824234cc80b4b7ded995c2948f9d.md)
Company: RED WINNERS