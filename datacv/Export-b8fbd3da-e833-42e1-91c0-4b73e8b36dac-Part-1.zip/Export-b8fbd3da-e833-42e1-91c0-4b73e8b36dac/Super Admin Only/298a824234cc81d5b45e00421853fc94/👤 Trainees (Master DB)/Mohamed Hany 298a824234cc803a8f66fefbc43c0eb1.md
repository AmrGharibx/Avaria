# Mohamed Hany

Assessment: Final (../%F0%9F%93%88%20Assessments%20(Master%20DB)/Final%2029ba824234cc809fa3a5da55f40e5b3d.md)
Attendance Logs: 1 (../%F0%9F%97%93%EF%B8%8F%20Daily%20Attendance%20Log%20(Master%20DB)/1%20298a824234cc8012ac8de529778bc746.md)
Batch: Batch 26 (../%F0%9F%8E%93%20Batches%20(Master%20DB)/Batch%2026%20298a824234cc80608179d6c569578ccd.md)
Company: RED