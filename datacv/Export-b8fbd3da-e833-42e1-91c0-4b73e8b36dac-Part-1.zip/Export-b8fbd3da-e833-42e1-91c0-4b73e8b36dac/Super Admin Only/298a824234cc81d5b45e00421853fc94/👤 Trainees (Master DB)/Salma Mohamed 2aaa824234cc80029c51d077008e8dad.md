# Salma Mohamed

Batch: Batch 22 (../%F0%9F%8E%93%20Batches%20(Master%20DB)/Batch%2022%202aaa824234cc800aaefef9854df7f97e.md)
Company: The Mediator