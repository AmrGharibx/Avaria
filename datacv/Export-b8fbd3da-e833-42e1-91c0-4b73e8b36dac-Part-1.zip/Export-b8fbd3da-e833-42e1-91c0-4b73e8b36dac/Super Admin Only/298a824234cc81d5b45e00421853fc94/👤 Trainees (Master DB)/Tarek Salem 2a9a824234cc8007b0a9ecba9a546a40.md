# Tarek Salem

Assessment: Final Batch 12 (../%F0%9F%93%88%20Assessments%20(Master%20DB)/Final%20Batch%2012%202ada824234cc8044ac20f6cab72efee9.md)
Batch: Batch 12 (../%F0%9F%8E%93%20Batches%20(Master%20DB)/Batch%2012%202a9a824234cc80638183e5ca92838164.md)
Company: Trio Homes