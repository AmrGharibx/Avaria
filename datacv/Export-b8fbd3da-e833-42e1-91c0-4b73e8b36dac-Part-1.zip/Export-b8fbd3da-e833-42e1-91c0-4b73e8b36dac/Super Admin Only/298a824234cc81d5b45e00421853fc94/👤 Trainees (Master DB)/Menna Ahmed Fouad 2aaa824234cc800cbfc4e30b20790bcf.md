# Menna Ahmed Fouad

Assessment: Final Batch 14 (../%F0%9F%93%88%20Assessments%20(Master%20DB)/Final%20Batch%2014%202aea824234cc8052aa70e515d0a464e0.md)
Batch: Batch 14 (../%F0%9F%8E%93%20Batches%20(Master%20DB)/Batch%2014%202aaa824234cc808f8e3ffe192d061526.md)
Company: RED