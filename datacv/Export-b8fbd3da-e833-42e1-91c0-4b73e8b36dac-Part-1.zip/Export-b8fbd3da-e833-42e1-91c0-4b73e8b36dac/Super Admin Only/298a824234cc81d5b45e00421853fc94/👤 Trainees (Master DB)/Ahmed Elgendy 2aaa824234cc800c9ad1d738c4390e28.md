# Ahmed Elgendy

Assessment: Final Batch 18 (../%F0%9F%93%88%20Assessments%20(Master%20DB)/Final%20Batch%2018%202aea824234cc80fc8a91f09a8ecab9af.md)
Batch: Batch 18 (../%F0%9F%8E%93%20Batches%20(Master%20DB)/Batch%2018%202aaa824234cc80d99587c324e4159234.md)
Company: RED