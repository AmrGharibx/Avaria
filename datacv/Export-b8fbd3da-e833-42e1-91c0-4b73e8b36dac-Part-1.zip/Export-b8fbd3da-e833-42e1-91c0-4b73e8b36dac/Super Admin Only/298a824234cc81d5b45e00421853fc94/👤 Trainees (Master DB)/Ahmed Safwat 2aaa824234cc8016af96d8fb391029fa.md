# Ahmed Safwat

Assessment: Final Batch 24 (../%F0%9F%93%88%20Assessments%20(Master%20DB)/Final%20Batch%2024%202afa824234cc801486bac264db3f4308.md)
Batch: Batch 24 (../%F0%9F%8E%93%20Batches%20(Master%20DB)/Batch%2024%202aaa824234cc8067aceaf77d508c3f9e.md)
Company: RED