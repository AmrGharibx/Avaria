# Nagham Ahmed Saied

Assessment: Final Batch 7 (../%F0%9F%93%88%20Assessments%20(Master%20DB)/Final%20Batch%207%202aba824234cc80c9a7accb464715da27.md)
Batch: Batch 7 (../%F0%9F%8E%93%20Batches%20(Master%20DB)/Batch%207%202a9a824234cc8097834dc5ea9c0d8f9c.md)
Company: RED