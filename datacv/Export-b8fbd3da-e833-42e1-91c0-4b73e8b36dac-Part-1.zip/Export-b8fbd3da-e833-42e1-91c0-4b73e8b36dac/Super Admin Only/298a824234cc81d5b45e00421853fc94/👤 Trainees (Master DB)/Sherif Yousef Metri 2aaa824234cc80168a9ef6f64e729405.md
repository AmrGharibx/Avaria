# Sherif Yousef Metri

Assessment: Final Batch 16 (../%F0%9F%93%88%20Assessments%20(Master%20DB)/Final%20Batch%2016%202aea824234cc807ba47ed21124cb6b0e.md)
Batch: Batch 16 (../%F0%9F%8E%93%20Batches%20(Master%20DB)/Batch%2016%202aaa824234cc80068dc2ca275afcbc3e.md)
Company: Builidivia