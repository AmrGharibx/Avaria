# Ahmed Helmy

Assessment: Final Batch 9 (../%F0%9F%93%88%20Assessments%20(Master%20DB)/Final%20Batch%209%202ada824234cc8076bf8cdd4235b20ac8.md)
Batch: Batch 9 (../%F0%9F%8E%93%20Batches%20(Master%20DB)/Batch%209%202a9a824234cc8017a36ae8b35a8eda97.md)
Company: Roots