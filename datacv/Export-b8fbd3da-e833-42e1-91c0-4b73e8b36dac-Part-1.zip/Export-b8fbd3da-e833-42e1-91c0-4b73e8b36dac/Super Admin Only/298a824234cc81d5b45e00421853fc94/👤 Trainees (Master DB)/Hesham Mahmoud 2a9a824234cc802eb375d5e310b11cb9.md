# Hesham Mahmoud

Assessment: Final Batch 8 (../%F0%9F%93%88%20Assessments%20(Master%20DB)/Final%20Batch%208%202aca824234cc80b28cd7c6d136c9acb8.md)
Batch: Batch 8 (../%F0%9F%8E%93%20Batches%20(Master%20DB)/Batch%208%202a9a824234cc80b6b104dda29aa97e6f.md)
Company: BYOUT