# Anna Simone Emad

Assessment: Final  (../%F0%9F%93%88%20Assessments%20(Master%20DB)/Final%2029ba824234cc806790dbe35d3081638a.md)
Batch: Batch 26 (../%F0%9F%8E%93%20Batches%20(Master%20DB)/Batch%2026%20298a824234cc80608179d6c569578ccd.md)
Company: Jumeirah