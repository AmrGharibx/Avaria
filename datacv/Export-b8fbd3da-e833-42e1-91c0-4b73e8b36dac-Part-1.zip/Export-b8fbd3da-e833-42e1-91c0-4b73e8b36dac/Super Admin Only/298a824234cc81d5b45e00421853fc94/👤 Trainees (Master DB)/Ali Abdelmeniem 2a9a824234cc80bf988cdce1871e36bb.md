# Ali Abdelmeniem

Assessment: Final Batch 10 (../%F0%9F%93%88%20Assessments%20(Master%20DB)/Final%20Batch%2010%202ada824234cc803ab820fa921e0d6ab6.md)
Batch: Batch 10 (../%F0%9F%8E%93%20Batches%20(Master%20DB)/Batch%2010%202a9a824234cc80d7a780d4a92e719468.md)
Company: RED