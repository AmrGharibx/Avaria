# Joudy Mohy Abdelmenem

Assessment: Final Batch 10 (../%F0%9F%93%88%20Assessments%20(Master%20DB)/Final%20Batch%2010%202ada824234cc8046be00e1d6bf5f9f80.md)
Batch: Batch 10 (../%F0%9F%8E%93%20Batches%20(Master%20DB)/Batch%2010%202a9a824234cc80d7a780d4a92e719468.md)
Company: Propertunity