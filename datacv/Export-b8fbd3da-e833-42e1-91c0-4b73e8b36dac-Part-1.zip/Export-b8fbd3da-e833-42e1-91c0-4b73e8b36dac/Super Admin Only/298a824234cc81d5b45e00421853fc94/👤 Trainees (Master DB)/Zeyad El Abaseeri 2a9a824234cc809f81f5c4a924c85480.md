# Zeyad El Abaseeri

Assessment: Final Batch 5 (../%F0%9F%93%88%20Assessments%20(Master%20DB)/Final%20Batch%205%202aaa824234cc8042bcf6e57e9f1f80aa.md)
Batch: Batch 5 (../%F0%9F%8E%93%20Batches%20(Master%20DB)/Batch%205%202a9a824234cc805d82b7e45111c5ce59.md)
Company: Impact