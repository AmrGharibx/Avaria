# Habiba Essam

Batch: Batch 12 (../%F0%9F%8E%93%20Batches%20(Master%20DB)/Batch%2012%202a9a824234cc80638183e5ca92838164.md)
Company: Projex