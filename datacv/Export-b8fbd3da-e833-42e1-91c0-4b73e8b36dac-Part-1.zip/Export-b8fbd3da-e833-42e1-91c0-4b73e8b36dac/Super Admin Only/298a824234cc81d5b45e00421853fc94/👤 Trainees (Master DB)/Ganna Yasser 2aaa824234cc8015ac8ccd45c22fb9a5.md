# Ganna Yasser

Assessment: Final Batch 23 (../%F0%9F%93%88%20Assessments%20(Master%20DB)/Final%20Batch%2023%202afa824234cc80ab9636c917502f4b28.md)
Batch: Batch 23 (../%F0%9F%8E%93%20Batches%20(Master%20DB)/Batch%2023%202aaa824234cc80928bb0d908b60ee8c1.md)
Company: The Mediator