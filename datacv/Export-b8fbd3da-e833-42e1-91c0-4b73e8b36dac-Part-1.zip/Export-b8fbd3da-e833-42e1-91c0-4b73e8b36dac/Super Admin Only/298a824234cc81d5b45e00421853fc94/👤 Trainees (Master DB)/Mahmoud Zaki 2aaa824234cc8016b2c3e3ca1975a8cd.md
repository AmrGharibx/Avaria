# Mahmoud Zaki

Assessment: Final Batch 17 (../%F0%9F%93%88%20Assessments%20(Master%20DB)/Final%20Batch%2017%202aea824234cc80ea94f9f2031e38b1ef.md)
Batch: Batch 17 (../%F0%9F%8E%93%20Batches%20(Master%20DB)/Batch%2017%202aaa824234cc80dfa8fee4f391af0218.md)
Company: Great Castle