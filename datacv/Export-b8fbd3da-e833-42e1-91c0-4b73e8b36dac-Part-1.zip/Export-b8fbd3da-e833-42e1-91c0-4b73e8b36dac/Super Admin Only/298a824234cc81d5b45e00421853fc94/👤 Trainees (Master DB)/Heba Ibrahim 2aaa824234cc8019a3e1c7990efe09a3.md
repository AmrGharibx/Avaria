# Heba Ibrahim

Assessment: Final Batch 21 (../%F0%9F%93%88%20Assessments%20(Master%20DB)/Final%20Batch%2021%202afa824234cc802a913ae1127b5a9cdc.md)
Batch: Batch 21 (../%F0%9F%8E%93%20Batches%20(Master%20DB)/Batch%2021%202aaa824234cc80678822ea74965f8556.md)
Company: Builidivia