# Passant Gamal

Assessment: Final Batch 20 (../%F0%9F%93%88%20Assessments%20(Master%20DB)/Final%20Batch%2020%202afa824234cc80f3b5a6f62f538c0ec7.md)
Batch: Batch 20 (../%F0%9F%8E%93%20Batches%20(Master%20DB)/Batch%2020%202aaa824234cc801e83cbd3cfc7c64632.md)
Company: The Mediator