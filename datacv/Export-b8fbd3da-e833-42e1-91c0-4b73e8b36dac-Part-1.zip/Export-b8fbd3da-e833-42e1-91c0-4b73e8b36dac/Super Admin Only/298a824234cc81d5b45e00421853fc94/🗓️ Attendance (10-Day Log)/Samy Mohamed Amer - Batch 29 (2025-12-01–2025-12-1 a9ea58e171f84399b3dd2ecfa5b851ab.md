# Samy Mohamed Amer - Batch 29 (2025-12-01–2025-12-10)

Absent (10 days): 2025-12-01 - Samy Mohamed Amer,2025-12-02 - Samy Mohamed Amer,2025-12-03 - Samy Mohamed Amer,2025-12-04 - Samy Mohamed Amer,2025-12-05 - Samy Mohamed Amer,2025-12-06 - Samy Mohamed Amer,2025-12-07 - Samy Mohamed Amer,2025-12-08 - Samy Mohamed Amer,2025-12-09 - Samy Mohamed Amer,2025-12-10 - Samy Mohamed Amer
Batch: Batch 29 (../%F0%9F%8E%93%20Batches%20(Master%20DB)/Batch%2029%202c4a824234cc8027b744f6714bbb681f.md)
Completion %: 60
Daily Entries: 2025-12-01 - Samy Mohamed Amer (../%F0%9F%97%93%EF%B8%8F%20Daily%20Attendance%20Log%20(Master%20DB)/2025-12-01%20-%20Samy%20Mohamed%20Amer%204cc35776fc5347939bd0bad63d647651.md), 2025-12-02 - Samy Mohamed Amer (../%F0%9F%97%93%EF%B8%8F%20Daily%20Attendance%20Log%20(Master%20DB)/2025-12-02%20-%20Samy%20Mohamed%20Amer%209cc16196195b47f4a462749af8c79d2d.md), 2025-12-03 - Samy Mohamed Amer (../%F0%9F%97%93%EF%B8%8F%20Daily%20Attendance%20Log%20(Master%20DB)/2025-12-03%20-%20Samy%20Mohamed%20Amer%2077999fcbe8b14c8daa907fd20d61ca82.md), 2025-12-04 - Samy Mohamed Amer (../%F0%9F%97%93%EF%B8%8F%20Daily%20Attendance%20Log%20(Master%20DB)/2025-12-04%20-%20Samy%20Mohamed%20Amer%203f24cb05438742d2a65e10e56b473e18.md), 2025-12-05 - Samy Mohamed Amer (../%F0%9F%97%93%EF%B8%8F%20Daily%20Attendance%20Log%20(Master%20DB)/2025-12-05%20-%20Samy%20Mohamed%20Amer%201e5bfda859cf4713bc9110250685c702.md), 2025-12-06 - Samy Mohamed Amer (../%F0%9F%97%93%EF%B8%8F%20Daily%20Attendance%20Log%20(Master%20DB)/2025-12-06%20-%20Samy%20Mohamed%20Amer%207b705b9ee43a440a81c83fda005d7110.md), 2025-12-07 - Samy Mohamed Amer (../%F0%9F%97%93%EF%B8%8F%20Daily%20Attendance%20Log%20(Master%20DB)/2025-12-07%20-%20Samy%20Mohamed%20Amer%200c48a6f2ddd5412792b2ef40af19c1c6.md), 2025-12-08 - Samy Mohamed Amer (../%F0%9F%97%93%EF%B8%8F%20Daily%20Attendance%20Log%20(Master%20DB)/2025-12-08%20-%20Samy%20Mohamed%20Amer%2079de98bf3dd84204b1f2fba52fd2ff43.md), 2025-12-09 - Samy Mohamed Amer (../%F0%9F%97%93%EF%B8%8F%20Daily%20Attendance%20Log%20(Master%20DB)/2025-12-09%20-%20Samy%20Mohamed%20Amer%201203fb7902f0413ab1d014497ca9a815.md), 2025-12-10 - Samy Mohamed Amer (../%F0%9F%97%93%EF%B8%8F%20Daily%20Attendance%20Log%20(Master%20DB)/2025-12-10%20-%20Samy%20Mohamed%20Amer%2028c028d067b8499099677ddba8a0db08.md)
Day 1: No
Day 10: Yes
Day 2: Yes
Day 3: Yes
Day 4: Yes
Day 5: Yes
Day 6: Yes
Day 7: Yes
Day 8: Yes
Day 9: Yes
Late (10 days): 2025-12-01 - Samy Mohamed Amer,2025-12-02 - Samy Mohamed Amer,2025-12-03 - Samy Mohamed Amer,2025-12-04 - Samy Mohamed Amer,2025-12-05 - Samy Mohamed Amer,2025-12-06 - Samy Mohamed Amer,2025-12-07 - Samy Mohamed Amer,2025-12-08 - Samy Mohamed Amer,2025-12-09 - Samy Mohamed Amer,2025-12-10 - Samy Mohamed Amer
Period End: December 10, 2025
Period Start: December 1, 2025
Present (10 days): 2025-12-01 - Samy Mohamed Amer,2025-12-02 - Samy Mohamed Amer,2025-12-03 - Samy Mohamed Amer,2025-12-04 - Samy Mohamed Amer,2025-12-05 - Samy Mohamed Amer,2025-12-06 - Samy Mohamed Amer,2025-12-07 - Samy Mohamed Amer,2025-12-08 - Samy Mohamed Amer,2025-12-09 - Samy Mohamed Amer,2025-12-10 - Samy Mohamed Amer
Trainee: Samy Mohamed Amer (../%F0%9F%91%A4%20Trainees%20(Master%20DB)/Samy%20Mohamed%20Amer%202c4a824234cc80848ee4c212dc3416d3.md)