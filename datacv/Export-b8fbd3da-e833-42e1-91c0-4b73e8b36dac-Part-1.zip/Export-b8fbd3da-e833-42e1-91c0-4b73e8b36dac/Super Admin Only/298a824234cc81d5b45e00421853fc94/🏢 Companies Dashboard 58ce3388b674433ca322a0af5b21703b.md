# 🏢 Companies Dashboard

<aside>
🏢

This page shows all trainees who have ever attended the academy, grouped by their company.

</aside>

[Untitled](%F0%9F%8F%A2%20Companies%20Dashboard/Untitled%206d99caec8ba942619c41811b4aadd5db.csv)