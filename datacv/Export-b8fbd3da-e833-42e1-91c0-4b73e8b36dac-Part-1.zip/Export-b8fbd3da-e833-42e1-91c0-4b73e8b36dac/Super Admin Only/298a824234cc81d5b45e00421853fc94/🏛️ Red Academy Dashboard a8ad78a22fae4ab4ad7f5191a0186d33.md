# 🏛️ Red Academy Dashboard

![Red Academy](https://upload.wikimedia.org/wikipedia/commons/b/bf/Golden_Gate_Bridge_as_seen_from_Battery_East.jpg)

<aside>
🎓

Welcome to the Red Academy Dashboard. Use the views below to manage batches across their lifecycle.

</aside>

### Active Batches

[Untitled](%F0%9F%8F%9B%EF%B8%8F%20Red%20Academy%20Dashboard/Untitled%209aae9e5a51d14151aef73f222560f635.csv)

### Planning Batches

[Untitled](%F0%9F%8F%9B%EF%B8%8F%20Red%20Academy%20Dashboard/Untitled%20039bf7ed6ede4acbbf9cca59e88d9d51.csv)

### Completed Batches

[Untitled](%F0%9F%8F%9B%EF%B8%8F%20Red%20Academy%20Dashboard/Untitled%20553e473af81b4b668acbabf85d635510.csv)