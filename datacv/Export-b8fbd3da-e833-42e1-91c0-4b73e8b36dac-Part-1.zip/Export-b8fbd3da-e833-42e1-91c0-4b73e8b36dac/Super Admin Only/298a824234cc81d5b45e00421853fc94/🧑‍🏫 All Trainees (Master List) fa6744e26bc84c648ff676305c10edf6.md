# 🧑‍🏫 All Trainees (Master List)

[All Trainees](%F0%9F%A7%91%E2%80%8D%F0%9F%8F%AB%20All%20Trainees%20(Master%20List)/All%20Trainees%200967430612d745d0b9c5262a83bef9c2.csv)